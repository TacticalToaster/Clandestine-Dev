local LOOT = {
	["boxed_backpack"] = 40,
	["handheld_radio"] = 20,
	["zip_tie"] = 10,
	["cw_flashgrenade"] = 10,
	["cw_smokegrenade"] = 10,
	["weapon_frag"] = 5,
	["broken_pistol"] = 2,
	["broken_smg1"] = 1,
	["weapon_shotgun"] = 1,
	["broken_357"] = 1
};
LOOTFEST:CreateLootTable("new_military", LOOT);