local LOOT = {
	["scrap_aluminum"] = 13,
	["scrap_copper"] = 13,
	["scrap_iron"] = 12,
	["wood_piece"] = 11,
	["epoxy"] = 10,
	["weapon_hl2pipe"] = 6,
	["plate_aluminum"] = 5,
	["plate_iron"] = 5,
	["plate_steel"] = 5,
	["scrap_electronics"] = 5,
	["hammer"] = 5,
	["screwdriver"] = 5,
	["wrench"] = 5
};
LOOTFEST:CreateLootTable("tinkers", LOOT);