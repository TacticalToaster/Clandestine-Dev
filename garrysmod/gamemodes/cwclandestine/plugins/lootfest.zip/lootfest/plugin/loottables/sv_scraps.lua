local LOOT = {
	["wood_piece"] = 20,
	["scrap_plastic"] = 15,
	["scrap_cloth"] = 15,
	["scrap_aluminum"] = 10,
	["scrap_copper"] = 10,
	["scrap_iron"] = 5,
	["scrap_nylon"] = 5,
	["scrap_steel"] = 5,
	["scrap_electronics"] = 5,
	["scrap_kevlar"] = 5,
	["scrap_gold"] = 5
};
LOOTFEST:CreateLootTable("scraps", LOOT);