local LOOT = {
	["boxed_bag"] = 25,
	["suitcase"] = 25,
	["vegetable_oil"] = 25,
	["bleach"] = 15,
	["weapon_hl2bottle"] = 10
};
LOOTFEST:CreateLootTable("retail", LOOT);