local LOOT = {
	["boxed_bag"] = 43,
	["boxed_backpack"] = 20,
	["handheld_radio"] = 15,
	["breach"] = 10,
	["zip_tie"] = 10,
	["broken_pistol"] = 2,
	["broken_smg1"] = 1
};
LOOTFEST:CreateLootTable("military", LOOT);