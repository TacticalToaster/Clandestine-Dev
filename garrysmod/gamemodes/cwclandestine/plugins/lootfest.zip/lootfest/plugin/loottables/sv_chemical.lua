local LOOT = {
	["epoxy"] = 22,
	["gasoline_can"] = 22,
	["acid_sulfuric"] = 16,
	["acid_nitric"] = 16,
	["guncotton"] = 12,
	["gunpowder"] = 12
};
LOOTFEST:CreateLootTable("chemical", LOOT);