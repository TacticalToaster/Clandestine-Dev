local LOOT = {
	["hammer"] = 22,
	["screwdriver"] = 22,
	["wrench"] = 22,
	["epoxy"] = 9,
	["scrap_iron"] = 9,
	["scrap_aluminum"] = 8,
	["scrap_steel"] = 8
};
LOOTFEST:CreateLootTable("toolbox", LOOT);