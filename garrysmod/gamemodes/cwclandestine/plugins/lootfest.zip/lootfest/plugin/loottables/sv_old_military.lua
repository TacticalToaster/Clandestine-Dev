local LOOT = {
	["boxed_bag"] = 25,
	["bandage"] = 25,
	["boxed_backpack"] = 15,
	["handheld_radio"] = 10,
	["zip_tie"] = 10,
	["ammo_pistol"] = 10,
	["ammo_smg1"] = 5
};
LOOTFEST:CreateLootTable("old_military", LOOT);