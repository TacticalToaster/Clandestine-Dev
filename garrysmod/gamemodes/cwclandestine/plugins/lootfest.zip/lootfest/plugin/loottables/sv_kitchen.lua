local LOOT = {
	["vegetable_oil"] = 25,
	["melon"] = 20,
	["milk_carton"] = 15,
	["beer"] = 15,
	["weapon_hl2bottle"] = 15,
	["bleach"] = 10
};
LOOTFEST:CreateLootTable("kitchen", LOOT);