local LOOT = {
	["scrap_cloth"] = 40,
	["scrap_nylon"] = 20,
	["scrap_kevlar"] = 15,
	["sewkit"] = 15
};
LOOTFEST:CreateLootTable("sewingkit", LOOT);