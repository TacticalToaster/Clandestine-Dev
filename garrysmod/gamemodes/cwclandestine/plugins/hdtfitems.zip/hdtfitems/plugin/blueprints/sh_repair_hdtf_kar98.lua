local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Repair";
BLUEPRINT.description = "German re-engineering.";
BLUEPRINT.model = "models/hunt_down_the_freeman/weapons/w_k98.mdl";
BLUEPRINT.name = "Kar 98k";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["broken_hdtf_kar98"] = 1,
	["plate_iron"] = 1,
	["wood_piece"] = 7,
	["epoxy"] = 1,
	["screwdriver"] = 1
};

BLUEPRINT.takeItems = {
    ["broken_hdtf_kar98"] = 1,
	["plate_iron"] = 1,
	["wood_piece"] = 7,
	["epoxy"] = 1
};

BLUEPRINT.giveItems = {
    ["hdtf_kar98"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();