local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Ammo";
BLUEPRINT.description = "More bullets, more chances for 'accidents.'";
BLUEPRINT.model = "models/Items/BoxSRounds.mdl";
BLUEPRINT.name = ".45 ACP Ammo (HDTF)";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
	["gunpowder"] = 3,
	["shell_casing"] = 3,
	["lead_bullet"] = 3
};

BLUEPRINT.takeItems = {
    ["gunpowder"] = 3,
	["shell_casing"] = 3,
	["lead_bullet"] = 3
};

BLUEPRINT.giveItems = {
    ["ammo_hdtf_45cal"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();