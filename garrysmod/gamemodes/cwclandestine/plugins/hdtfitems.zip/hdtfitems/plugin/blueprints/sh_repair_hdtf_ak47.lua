local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Repair";
BLUEPRINT.description = "They're reliable before and after being broke, right?";
BLUEPRINT.model = "models/hunt_down_the_freeman/weapons/w_ak47.mdl";
BLUEPRINT.name = "AK-47";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["broken_hdtf_ak47"] = 1,
	["plate_iron"] = 2,
	["wood_piece"] = 5,
	["epoxy"] = 1,
	["screwdriver"] = 1
};

BLUEPRINT.takeItems = {
    ["broken_hdtf_ak47"] = 1,
	["plate_iron"] = 2,
	["wood_piece"] = 5,
	["epoxy"] = 1
};

BLUEPRINT.giveItems = {
    ["hdtf_ak47"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();