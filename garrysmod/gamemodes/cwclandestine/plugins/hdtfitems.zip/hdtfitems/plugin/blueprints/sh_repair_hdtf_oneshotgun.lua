local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Repair";
BLUEPRINT.description = "Do you ever wonder what happens when you fix a broken shotgun that has been dangerously modified?";
BLUEPRINT.model = "models/hunt_down_the_freeman/weapons/w_oneshotgun.mdl";
BLUEPRINT.name = "Sawed-off Shotgun";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["broken_hdtf_oneshotgun"] = 1,
	["plate_iron"] = 1,
	["wood_piece"] = 4,
	["epoxy"] = 1,
	["screwdriver"] = 1
};

BLUEPRINT.takeItems = {
    ["broken_hdtf_oneshotgun"] = 1,
	["plate_iron"] = 1,
	["wood_piece"] = 4,
	["epoxy"] = 1
};

BLUEPRINT.giveItems = {
    ["hdtf_oneshotgun"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();