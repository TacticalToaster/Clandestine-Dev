local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Breakdown";
BLUEPRINT.description = "So many little pellets.";
BLUEPRINT.model = "models/hunt_down_the_freeman/weapons/ammo_buckshot.mdl";
BLUEPRINT.name = "Breakdown .12g Buckshot (HDTF)";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
	["ammo_hdtf_buckshot"] = 1
};

BLUEPRINT.takeItems = {
    ["ammo_hdtf_buckshot"] = 1
};

BLUEPRINT.giveItems = {
    ["gunpowder"] = 2,
	["scrap_plastic"] = 2,
	["scrap_iron"] = 2
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();