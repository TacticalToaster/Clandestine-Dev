local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Weapon";
BLUEPRINT.description = "A little bit of soap and gasoline never hurt anyone.";
BLUEPRINT.model = "models/hunt_down_the_freeman/weapons/w_molotov.mdl";
BLUEPRINT.name = "Molotov Cocktail";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["weapon_hl2bottle"] = 1,
    ["gasoline_can"] = 1,
    ["scrap_cloth"] = 1
};

BLUEPRINT.takeItems = {
	["weapon_hl2bottle"] = 1,
	["gasoline_can"] = 1,
    ["scrap_cloth"] = 1
};

BLUEPRINT.giveItems = {
    ["hdtf_molotov"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();