--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("grenade_base");
	ITEM.name = "Molotov Cocktail";
	ITEM.cost = 30;
	ITEM.model = "models/hunt_down_the_freeman/weapons/w_molotov.mdl";
	ITEM.weight = 1;
	ITEM.access = "V";
	ITEM.uniqueID = "hdtf_molotov";
	ITEM.business = true;
	ITEM.description = "A beer bottle filled with gasoline and some dish soap.";
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(90, 0, 0);
	ITEM.attachmentOffsetVector = Vector(0, 6.55, 8.72);
ITEM:Register();