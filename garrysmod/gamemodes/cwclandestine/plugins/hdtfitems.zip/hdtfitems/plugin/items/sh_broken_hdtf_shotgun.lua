local ITEM = Clockwork.item:New();
ITEM.name = "Broken Remington 870";
ITEM.uniqueID = "broken_hdtf_shotgun";
ITEM.model = "models/hunt_down_the_freeman/weapons/w_rem870.mdl";
ITEM.weight = 3.2;
ITEM.description = "A broken Remington 870 shotgun. Could it be fixed?";

-- Called when a player attempts to pick up the item.
function ITEM:CanPickup(player, quickUse, itemEntity)
    if (quickUse) then
        if (!player:CanHoldWeight(self.weight)) then
            Clockwork.player:Notify(player, "You do not have enough inventory space!");
           
            return false;
        end;
    end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();