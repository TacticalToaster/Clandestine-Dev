--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("grenade_base");
	ITEM.name = "Flare";
	ITEM.cost = 20;
	ITEM.model = "models/hunt_down_the_freeman/weapons/w_flare.mdl";
	ITEM.weight = 0.8;
	ITEM.access = "v";
	ITEM.uniqueID = "hdtf_flare";
	ITEM.business = true;
	ITEM.description = "A tall red stick. Taking the top off and striking the stick lights it.";
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(90, 0, 0);
	ITEM.attachmentOffsetVector = Vector(0, 6.55, 8.72);
ITEM:Register();