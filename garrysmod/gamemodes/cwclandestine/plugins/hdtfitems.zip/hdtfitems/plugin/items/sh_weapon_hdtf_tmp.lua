--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "TMP";
	ITEM.cost = 240;
	ITEM.model = "models/hunt_down_the_freeman/weapons/w_tmp.mdl";
	ITEM.weight = 2.1;
	ITEM.access = "V";
	ITEM.uniqueID = "hdtf_tmp";
	ITEM.business = true;
	ITEM.description = "A very compact machine pistol made of polymer.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-2, 5, 4);
ITEM:Register();