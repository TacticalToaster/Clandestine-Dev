--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("grenade_base");
	ITEM.name = "Painkillers";
	ITEM.cost = 15;
	ITEM.model = "models/hunt_down_the_freeman/weapons/w_pills.mdl";
	ITEM.weight = 0.2;
	ITEM.access = "v";
	ITEM.uniqueID = "hdtf_pills";
	ITEM.business = true;
	ITEM.description = "A small pill bottle. There's only a few pills inside.";
ITEM:Register();