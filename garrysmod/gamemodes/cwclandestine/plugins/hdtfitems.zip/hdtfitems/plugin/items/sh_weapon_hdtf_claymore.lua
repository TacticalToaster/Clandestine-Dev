--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("grenade_base");
	ITEM.name = "M18 Claymore";
	ITEM.cost = 60;
	ITEM.model = "models/hunt_down_the_freeman/weapons/w_claymore.mdl";
	ITEM.weight = 0.8;
	ITEM.access = "V";
	ITEM.uniqueID = "hdtf_claymore";
	ITEM.business = true;
	ITEM.description = "An anti-personnel mine that is an olive green color.";
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(90, 0, 0);
	ITEM.attachmentOffsetVector = Vector(0, 6.55, 8.72);
ITEM:Register();