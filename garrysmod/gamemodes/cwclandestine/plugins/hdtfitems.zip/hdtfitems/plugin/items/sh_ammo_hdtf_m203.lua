--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = "40mm Grenades";
	ITEM.cost = 30;
	ITEM.model = "models/Items/BoxMRounds.mdl";
	ITEM.weight = 2;
	ITEM.access = "V";
	ITEM.uniqueID = "ammo_hdtf_m203";
	ITEM.business = true;
	ITEM.ammoClass = "hdtf_ammo_m203";
	ITEM.ammoAmount = 10;
	ITEM.description = "A heavy container filled with 40mm grenades.";
ITEM:Register();