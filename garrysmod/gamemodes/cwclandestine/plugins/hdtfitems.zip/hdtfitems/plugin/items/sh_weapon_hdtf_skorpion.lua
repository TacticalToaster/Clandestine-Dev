--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "Skorpion";
	ITEM.cost = 175;
	ITEM.model = "models/hunt_down_the_freeman/weapons/w_skorpion.mdl";
	ITEM.weight = 1.3;
	ITEM.access = "V";
	ITEM.uniqueID = "hdtf_skorpion";
	ITEM.business = true;
	ITEM.description = "A small machine pistol made of wood and metal.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-2, 5, 4);
ITEM:Register();