--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = "XM214 Microgun";
	ITEM.cost = 10000;
	ITEM.model = "models/hunt_down_the_freeman/weapons/w_kitchen_knife.mdl";
	ITEM.weight = 20;
	ITEM.uniqueID = "hdtf_minigun";
	ITEM.business = false;
	ITEM.description = "A multi-barrel electric-operated gun that fires VERY fast.";
	ITEM.isAttachment = true;
	ITEM.hasFlashlight = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Spine";
	ITEM.attachmentOffsetAngles = Angle(0, 0, 0);
	ITEM.attachmentOffsetVector = Vector(-3.96, 4.95, -2.97);
ITEM:Register();