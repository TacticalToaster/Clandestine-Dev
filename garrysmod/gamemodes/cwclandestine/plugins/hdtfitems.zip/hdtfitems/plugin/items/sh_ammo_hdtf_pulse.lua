--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = "Pulse Cartidges";
	ITEM.cost = 30;
	ITEM.model = "models/hunt_down_the_freeman/weapons/ammo_ar2.mdl";
	ITEM.weight = 1;
	ITEM.access = "V";
	ITEM.uniqueID = "ammo_hdtf_pulse";
	ITEM.business = true;
	ITEM.ammoClass = "hdtf_ammo_pulse";
	ITEM.ammoAmount = 30;
	ITEM.description = "A strange shaped magazine to an AR2.";
ITEM:Register();