--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = "7.92mm Bullets";
	ITEM.cost = 30;
	ITEM.model = "models/Items/BoxMRounds.mdl";
	ITEM.weight = 2;
	ITEM.access = "V";
	ITEM.uniqueID = "ammo_hdtf_792mm";
	ITEM.business = true;
	ITEM.ammoClass = "hdtf_ammo_7.92mm";
	ITEM.ammoAmount = 30;
	ITEM.description = "A heavy container filled with a lot of 7.92mm bullets.";
ITEM:Register();