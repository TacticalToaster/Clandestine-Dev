local ITEM = Clockwork.item:New();
ITEM.name = "Broken Kar 98k";
ITEM.uniqueID = "broken_hdtf_kar98";
ITEM.model = "models/hunt_down_the_freeman/weapons/w_k98.mdl";
ITEM.weight = 3.7;
ITEM.description = "A broken Kar 98k. Could it be fixed?";

-- Called when a player attempts to pick up the item.
function ITEM:CanPickup(player, quickUse, itemEntity)
    if (quickUse) then
        if (!player:CanHoldWeight(self.weight)) then
            Clockwork.player:Notify(player, "You do not have enough inventory space!");
           
            return false;
        end;
    end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();