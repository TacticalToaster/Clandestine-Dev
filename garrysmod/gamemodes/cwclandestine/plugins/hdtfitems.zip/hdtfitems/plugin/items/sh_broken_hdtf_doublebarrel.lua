local ITEM = Clockwork.item:New();
ITEM.name = "Broken Double Barrel Shotgun";
ITEM.uniqueID = "broken_hdtf_doublebarrel";
ITEM.model = "models/hunt_down_the_freeman/weapons/w_doublebarrel.mdl";
ITEM.weight = 3.1;
ITEM.description = "A broken double barrel shotgun. Could it be fixed?";

-- Called when a player attempts to pick up the item.
function ITEM:CanPickup(player, quickUse, itemEntity)
    if (quickUse) then
        if (!player:CanHoldWeight(self.weight)) then
            Clockwork.player:Notify(player, "You do not have enough inventory space!");
           
            return false;
        end;
    end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();