--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = ".44 Mag Bullets";
	ITEM.cost = 30;
	ITEM.model = "models/hunt_down_the_freeman/weapons/ammo_magnum.mdl";
	ITEM.weight = 2;
	ITEM.access = "V";
	ITEM.uniqueID = "ammo_hdtf_44cal";
	ITEM.business = true;
	ITEM.ammoClass = "hdtf_ammo_.44cal";
	ITEM.ammoAmount = 30;
	ITEM.description = "A heavy container filled with a lot of .44 Mag bullets.";
ITEM:Register();