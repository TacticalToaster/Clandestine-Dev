--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("weapon_base");
	ITEM.name = ".44 Magnum";
	ITEM.cost = 325;
	ITEM.model = "models/hunt_down_the_freeman/weapons/w_magnum.mdl";
	ITEM.weight = 1.4;
	ITEM.access = "V";
	ITEM.uniqueID = "hdtf_magnum";
	ITEM.business = true;
	ITEM.description = "A large revolver that shoots an even larger round.";
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(-180, 180, 90);
	ITEM.attachmentOffsetVector = Vector(-4.19, 0, -8.54);
ITEM:Register();