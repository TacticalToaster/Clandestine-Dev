--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = "Buckshot";
	ITEM.cost = 30;
	ITEM.model = "models/hunt_down_the_freeman/weapons/ammo_buckshot.mdl";
	ITEM.weight = 1;
	ITEM.access = "V";
	ITEM.uniqueID = "ammo_hdtf_buckshot";
	ITEM.business = true;
	ITEM.ammoClass = "hdtf_ammo_buckshot";
	ITEM.ammoAmount = 30;
	ITEM.description = "A red box filled with .12g buckshot.";
ITEM:Register();