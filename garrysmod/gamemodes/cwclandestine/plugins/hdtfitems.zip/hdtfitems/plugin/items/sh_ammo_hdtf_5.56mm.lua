--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = "5.56mm Bullets";
	ITEM.cost = 30;
	ITEM.model = "models/Items/BoxMRounds.mdl";
	ITEM.weight = 2;
	ITEM.access = "V";
	ITEM.uniqueID = "ammo_hdtf_556mm";
	ITEM.business = true;
	ITEM.ammoClass = "hdtf_ammo_5.56mm";
	ITEM.ammoAmount = 30;
	ITEM.description = "A heavy container filled with a lot of 5.56mm bullets.";
ITEM:Register();