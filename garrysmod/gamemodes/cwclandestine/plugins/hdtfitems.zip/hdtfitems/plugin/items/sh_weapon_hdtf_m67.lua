--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("grenade_base");
	ITEM.name = "M67";
	ITEM.cost = 40;
	ITEM.model = "models/hunt_down_the_freeman/weapons/w_m67.mdl";
	ITEM.weight = 0.8;
	ITEM.access = "V";
	ITEM.uniqueID = "hdtf_m67";
	ITEM.business = true;
	ITEM.description = "A prewar offensive grenade used by the US.";
	ITEM.isAttachment = true;
	ITEM.loweredOrigin = Vector(3, 0, -4);
	ITEM.loweredAngles = Angle(0, 45, 0);
	ITEM.attachmentBone = "ValveBiped.Bip01_Pelvis";
	ITEM.attachmentOffsetAngles = Angle(90, 0, 0);
	ITEM.attachmentOffsetVector = Vector(0, 6.55, 8.72);
ITEM:Register();