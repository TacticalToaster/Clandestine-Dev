--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

local ITEM = Clockwork.item:New("ammo_base");
	ITEM.name = "Combine Balls";
	ITEM.cost = 50;
	ITEM.model = "models/Items/combine_rifle_ammo01.mdl";
	ITEM.weight = 2;
	ITEM.access = "V";
	ITEM.uniqueID = "ammo_hdtf_combineball";
	ITEM.business = true;
	ITEM.ammoClass = "hdtf_ammo_combineball";
	ITEM.ammoAmount = 3;
	ITEM.description = "A few combine balls used in AR2s.";
ITEM:Register();