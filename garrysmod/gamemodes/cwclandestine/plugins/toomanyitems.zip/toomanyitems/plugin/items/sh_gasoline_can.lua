local ITEM = Clockwork.item:New();
ITEM.name = "Gasoline Can";
ITEM.uniqueID = "gasoline_can";
ITEM.model = "models/props_junk/gascan001a.mdl";
ITEM.weight = 1;
ITEM.description = "Can be filled with gasoline.  Used for fuel or crafting.";

-- Called when a player attempts to pick up the item.
function ITEM:CanPickup(player, quickUse, itemEntity)
    if (quickUse) then
        if (!player:CanHoldWeight(self.weight)) then
            Clockwork.player:Notify(player, "You do not have enough inventory space!");
           
            return false;
        end;
    end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();