local ITEM = Clockwork.item:New();
ITEM.name = "Attenae";
ITEM.uniqueID = "attenae";
ITEM.model = "models/cheeze/wires/wireless_card.mdl";
ITEM.weight = .3;
ITEM.description = "An attenae for picking up radio signals. Could be used to make a radio.";

-- Called when a player attempts to pick up the item.
function ITEM:CanPickup(player, quickUse, itemEntity)
    if (quickUse) then
        if (!player:CanHoldWeight(self.weight)) then
            Clockwork.player:Notify(player, "You do not have enough inventory space!");
           
            return false;
        end;
    end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();