local ITEM = Clockwork.item:New();
ITEM.name = "Remote Detonator";
ITEM.uniqueID = "remote_detonator";
ITEM.model = "models/deadbodies/dead_male_civilian_radio.mdl";
ITEM.weight = .3;
ITEM.description = "A small device that seems to be a detonator for radio-controlled explosives.";
ITEM.customFunctions = {"Detonate"};

-- Called when a player attempts to pick up the item.
function ITEM:CanPickup(player, quickUse, itemEntity)
    if (quickUse) then
        if (!player:CanHoldWeight(self.weight)) then
            Clockwork.player:Notify(player, "You do not have enough inventory space!");
           
            return false;
        end;
    end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

if (SERVER) then
    function ITEM:OnCustomFunction(player, name)
        if (name == "Detonate") then
            local explosive = self:GetData("Explosive")
            if (IsValid(explosive)) then
                if (explosive:Explode()) then
                    Clockwork.player:Notify(player, "A beep confirms that the explosive was successfully triggered.");
                    player:EmitSound("buttons/combine_button1.wav");
                    self:RemoveData("Explosive");
                else
                    Clockwork.player:Notify(player, "A harsh beep reveals that something went wrong.");
                    player:EmitSound("buttons/combine_button_locked.wav");
                end;
            else
                Clockwork.player:Notify(player, "A harsh beep reveals that something went wrong.");
                player:EmitSound("buttons/combine_button_locked.wav");
            end;
        end;
    end;
end;

ITEM:Register();