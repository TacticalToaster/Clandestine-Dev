local ITEM = Clockwork.item:New();
ITEM.name = "Plastic Bundle";
ITEM.uniqueID = "bundle_plastic";
ITEM.model = "models/props_wasteland/prison_toiletchunk01g.mdl";
ITEM.weight = 1;
ITEM.description = "Chunk of old plastic. Could be used for cases and other things.";

-- Called when a player attempts to pick up the item.
function ITEM:CanPickup(player, quickUse, itemEntity)
    if (quickUse) then
        if (!player:CanHoldWeight(self.weight)) then
            Clockwork.player:Notify(player, "You do not have enough inventory space!");
           
            return false;
        end;
    end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();