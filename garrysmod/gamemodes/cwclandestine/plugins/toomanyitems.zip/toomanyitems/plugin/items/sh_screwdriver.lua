local ITEM = Clockwork.item:New();
ITEM.name = "Screwdriver";
ITEM.uniqueID = "screwdriver";
ITEM.model = "models/props_c17/TrapPropeller_Lever.mdl";
ITEM.weight = .8;
ITEM.category = "Tools";
ITEM.description = "A tool with a plastic handle and a skinny, long metal shaft.";

-- Called when a player attempts to pick up the item.
function ITEM:CanPickup(player, quickUse, itemEntity)
    if (quickUse) then
        if (!player:CanHoldWeight(self.weight)) then
            Clockwork.player:Notify(player, "You do not have enough inventory space!");
           
            return false;
        end;
    end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();