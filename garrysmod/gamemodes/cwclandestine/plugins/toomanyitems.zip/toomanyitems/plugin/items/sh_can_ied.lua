local ITEM = Clockwork.item:New();
ITEM.name = "Can IED";
ITEM.uniqueID = "can_ied";
ITEM.model = "models/props_junk/PopCan01a.mdl";
ITEM.weight = .5;
ITEM.description = "A can that is pretty heavy. There's some wiring in it.";

-- Called when a player attempts to pick up the item.
function ITEM:CanPickup(player, quickUse, itemEntity)
    if (quickUse) then
        if (!player:CanHoldWeight(self.weight)) then
            Clockwork.player:Notify(player, "You do not have enough inventory space!");
           
            return false;
        end;
    end;
end;

function ITEM:OnUse(player, itemEntity)
	local trace = player:GetEyeTraceNoCursor();

	if (player:GetShootPos():Distance(trace.HitPos) <= 192) then
		local ent = ents.Create("cw_can_ied");

		ent:SetPos(trace.HitPos + Vector(0, 0, 5));
		ent:Spawn()

		local det = Clockwork.item:CreateInstance("remote_detonator");
		det:AddData("Explosive", ent);
		player:GiveItem(det);
	else
		Clockwork.player:Notify(player, "You cannot plant the IED that far away!");
		return false;
	end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();