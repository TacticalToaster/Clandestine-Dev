local ITEM = Clockwork.item:New();
ITEM.name = "Steel Bundle";
ITEM.uniqueID = "bundle_steel";
ITEM.model = "models/gibs/manhack_gib01.mdl";
ITEM.weight = 1.5;
ITEM.description = "Steel scraps that are good for smelting and crafting.";

-- Called when a player attempts to pick up the item.
function ITEM:CanPickup(player, quickUse, itemEntity)
    if (quickUse) then
        if (!player:CanHoldWeight(self.weight)) then
            Clockwork.player:Notify(player, "You do not have enough inventory space!");
           
            return false;
        end;
    end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();