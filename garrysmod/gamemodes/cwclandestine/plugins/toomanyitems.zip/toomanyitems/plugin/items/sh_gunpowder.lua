local ITEM = Clockwork.item:New();
ITEM.name = "Gunpowder";
ITEM.uniqueID = "gunpowder";
ITEM.model = "models/props_lab/jar01a.mdl";
ITEM.weight = .3;
ITEM.description = "Jar containing gunpowder. Very useful for bombs, as it detonates instead of deflagrates.";

-- Called when a player attempts to pick up the item.
function ITEM:CanPickup(player, quickUse, itemEntity)
    if (quickUse) then
        if (!player:CanHoldWeight(self.weight)) then
            Clockwork.player:Notify(player, "You do not have enough inventory space!");
           
            return false;
        end;
    end;
end;

-- Called when a player drops the item.
function ITEM:OnDrop(player, position) end;

ITEM:Register();