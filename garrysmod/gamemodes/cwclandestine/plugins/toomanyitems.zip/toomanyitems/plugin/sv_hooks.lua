-- Called when an entity's menu option should be handled.
function TOOMANY:EntityHandleMenuOption(player, entity, option, arguments)
	local class = entity:GetClass();
	
	if (class == "cw_can_ied" and arguments == "cwDetonate") then
		entity:Explode();
	elseif (class == "cw_can_ied" and arguments == "cwArm") then
		entity:Arm();
	end;
end;