-- Called when an entity's menu options are needed.
function PLUGIN:GetEntityMenuOptions(entity, options)
	local class = entity:GetClass();
	
	if (class == "cw_can_ied") then
		options["Arm"] = "cwArm";
		options["Manually Detonate"] = "cwDetonate";
	end;
end;