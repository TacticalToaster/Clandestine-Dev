--[[
	� 2013 CloudSixteen.com do not share, re-distribute or modify
	without permission of its author (kurozael@gmail.com).
--]]

include("shared.lua");

AddCSLuaFile("cl_init.lua");
AddCSLuaFile("shared.lua");

-- Called when the entity initializes.
function ENT:Initialize()
	self:SetModel("models/props_junk/PopCan01a.mdl");
	
	self:SetMoveType(MOVETYPE_VPHYSICS);
	self:PhysicsInit(SOLID_VPHYSICS);
	self:SetUseType(SIMPLE_USE);
	self:SetSolid(SOLID_VPHYSICS);
	
	local physicsObject = self:GetPhysicsObject();
	
	if (IsValid(physicsObject)) then
		physicsObject:Wake();
		physicsObject:EnableMotion(true);
	end;
end;

-- Called when the entity's transmit state should be updated.
function ENT:UpdateTransmitState()
	return TRANSMIT_ALWAYS;
end;

-- A function to set the entity's flash duration.
function ENT:SetFlashDuration(duration)
	self:EmitSound("buttons/combine_button5.wav");
	self:SetDTFloat(0, CurTime() + duration);
end;

-- A function to emit a random sound from the entity.
function ENT:EmitRandomSound()
	local randomSounds = {
		"buttons/combine_button1.wav",
		"buttons/combine_button2.wav",
		"buttons/combine_button3.wav",
		"buttons/combine_button5.wav",
		"buttons/combine_button7.wav"
	};
	
	self:EmitSound( randomSounds[ math.random(1, #randomSounds) ] );
end;

--[[ Called when the entity's physics should be updated.
function ENT:PhysicsUpdate(physicsObject)
	if (!self:IsPlayerHolding() and !self:IsConstrained()) then
		physicsObject:SetVelocity( Vector(0, 0, 0) );
		physicsObject:Sleep();
	end;
end;]]

function ENT:Arm()
	if (self:GetDTBool(0) == false) then
 		self:SetDTBool(0, true);
 		self:SetFlashDuration(2);
	end;
end;

function ENT:Explode()
	if (self:GetDTBool(0) == false) then return false end;

	local KillDamage = 175;
	local KillRadius = 300;
	local InjureDamage = 50;
	local InjureRadius = 500;

	local explodeSound = Sound("BaseExplosionEffect.Sound");

	util.BlastDamage(self.Entity, self.Entity, self.Entity:GetPos(), KillRadius, KillDamage);
 	util.BlastDamage(self.Entity, self.Entity, self.Entity:GetPos(), InjureRadius, InjureDamage);

	local ed = EffectData();

	ed:SetOrigin(self.Entity:GetPos());
	ed:SetMagnitude(1);

	util.Effect("HelicopterMegaBomb", ed);
	util.Effect("Explosion", ed); // Big flame
	
	local shake = ents.Create("env_shake");
		//shake:SetOwner( self.Owner )
		shake:SetPos(self.Entity:GetPos());
		shake:SetKeyValue("amplitude", "6"); // Power of the shake
		shake:SetKeyValue("radius", tostring(KillRadius*3));	// Radius of the shake
		shake:SetKeyValue("duration", "1");	// Time of shake
		shake:SetKeyValue("frequency", "100"); // How hard should the screenshake be
		shake:SetKeyValue("spawnflags", "4"); // Spawnflags( In Air )
		shake:Spawn();
		shake:Activate();
		shake:Fire("StartShake", "", 0);
	
	self.Entity:EmitSound(explodeSound);
	self:Remove();

	return true;
end;