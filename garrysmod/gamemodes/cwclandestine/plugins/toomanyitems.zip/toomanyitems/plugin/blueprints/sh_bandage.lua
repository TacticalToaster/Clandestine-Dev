local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Medical";
BLUEPRINT.description = "Use spare cloth to make some dirty bandages.";
BLUEPRINT.model = "models/props_wasteland/prison_toiletchunk01i.mdl";
BLUEPRINT.name = "Bandage";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["scrap_cloth"] = 2
};

BLUEPRINT.takeItems = {
    ["scrap_cloth"] = 2
};

BLUEPRINT.giveItems = {
    ["bandage"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();