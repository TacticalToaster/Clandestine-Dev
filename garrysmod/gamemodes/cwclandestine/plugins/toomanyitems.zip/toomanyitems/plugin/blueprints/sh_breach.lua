local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Explosives";
BLUEPRINT.description = "A bit costly, but worth it if you want to break into places.";
BLUEPRINT.model = "models/props_wasteland/prison_padlock001a.mdll";
BLUEPRINT.name = "Breach";
BLUEPRINT.access = "E";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["plate_iron"] = 4,
    ["guncotton"] = 3,
    ["scrap_electronics"] = 1,
    ["hammer"] = 1,
    ["screwdriver"] = 1
};

BLUEPRINT.takeItems = {
    ["plate_iron"] = 4,
    ["guncotton"] = 3,
    ["scrap_electronics"] = 1
};

BLUEPRINT.giveItems = {
    ["breach"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();