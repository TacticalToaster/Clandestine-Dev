local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Unbundle";
BLUEPRINT.description = "Unbundle some electronics to make more space.";
BLUEPRINT.model = "models/props_lab/reciever01d.mdl";
BLUEPRINT.name = "Unbundle Electronics";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["bundle_electronics"] = 1
};

BLUEPRINT.takeItems = {
    ["bundle_electronics"] = 1
};

BLUEPRINT.giveItems = {
    ["scrap_electronics"] = 5
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();