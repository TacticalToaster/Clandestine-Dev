local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Unbundle";
BLUEPRINT.description = "Unbundle some plastic to make more space.";
BLUEPRINT.model = "models/props_wasteland/prison_toiletchunk01g.mdl";
BLUEPRINT.name = "Unbundle Plastic";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["bundle_plastic"] = 1
};

BLUEPRINT.takeItems = {
    ["bundle_plastic"] = 1
};

BLUEPRINT.giveItems = {
    ["scrap_plastic"] = 5
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();