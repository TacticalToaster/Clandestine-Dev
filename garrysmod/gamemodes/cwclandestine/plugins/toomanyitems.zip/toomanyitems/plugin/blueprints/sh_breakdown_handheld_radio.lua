local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Breakdown";
BLUEPRINT.description = "Getting the scrap from a radio isn't that hard.";
BLUEPRINT.model = "models/deadbodies/dead_male_civilian_radio.mdl";
BLUEPRINT.name = "Breakdown Handheld Radio";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
	["handheld_radio"] = 1,
	["screwdriver"] = 1
};

BLUEPRINT.takeItems = {
    ["handheld_radio"] = 1
};

BLUEPRINT.giveItems = {
    ["scrap_electronics"] = 3,
	["attenae"] = 1,
	["scrap_plastic"] = 4
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();