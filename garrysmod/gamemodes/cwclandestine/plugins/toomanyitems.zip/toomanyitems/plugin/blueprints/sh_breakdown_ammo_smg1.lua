local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Breakdown";
BLUEPRINT.description = "Many rounds, many lead.";
BLUEPRINT.model = "models/Items/BoxMRounds.mdl";
BLUEPRINT.name = "Breakdown 4.6x30mm Ammo";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
	["ammo_smg1"] = 1
};

BLUEPRINT.takeItems = {
    ["ammo_smg1"] = 1
};

BLUEPRINT.giveItems = {
    ["gunpowder"] = 3,
	["shell_casing"] = 3,
	["lead_bullet"] = 3
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();