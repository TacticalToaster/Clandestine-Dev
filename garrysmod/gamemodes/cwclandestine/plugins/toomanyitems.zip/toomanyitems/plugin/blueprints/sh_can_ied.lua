local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Explosives";
BLUEPRINT.description = "A small can can make all the difference.";
BLUEPRINT.model = "models/props_junk/PopCan01a.mdl";
BLUEPRINT.name = "Can IED";
BLUEPRINT.access = "E";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["junk_can"] = 1,
    ["guncotton"] = 4,
    ["scrap_electronics"] = 1,
    ["epoxy"] = 1
};

BLUEPRINT.takeItems = {
    ["junk_can"] = 1,
    ["guncotton"] = 4,
    ["scrap_electronics"] = 1
    ["epoxy"] = 1
};

BLUEPRINT.giveItems = {
    ["can_ied"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();