local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Communication";
BLUEPRINT.description = "Some old electronics here, a few attenaes there, and finally some iron plates... Ah, a radio!";
BLUEPRINT.model = "models/props_lab/citizenradio.mdl";
BLUEPRINT.name = "Stationary Radio";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["scrap_electronics"] = 4,
	["attenae"] = 2,
	["plate_iron"] = 4,
	["screwdriver"] = 1,
	["wrench"] = 1
};

BLUEPRINT.takeItems = {
    ["scrap_electronics"] = 4,
	["attenae"] = 2,
	["plate_iron"] = 4
};

BLUEPRINT.giveItems = {
    ["stationary_radio"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();