local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Unbundle";
BLUEPRINT.description = "Unbundle some gold to make more space.";
BLUEPRINT.model = "models/Items/AR2_Grenade.mdl";
BLUEPRINT.name = "Unbundle Gold";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["bundle_gold"] = 1
};

BLUEPRINT.takeItems = {
    ["bundle_gold"] = 1
};

BLUEPRINT.giveItems = {
    ["scrap_gold"] = 5
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();