local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Communication";
BLUEPRINT.description = "Who knew scrap electronics and an attenae can make a radio?";
BLUEPRINT.model = "models/deadbodies/dead_male_civilian_radio.mdl";
BLUEPRINT.name = "Handheld Radio";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["scrap_electronics"] = 3,
	["attenae"] = 1,
	["scrap_plastic"] = 4,
	["screwdriver"] = 1
};

BLUEPRINT.takeItems = {
    ["scrap_electronics"] = 3,
	["attenae"] = 1,
	["scrap_plastic"] = 4
};

BLUEPRINT.giveItems = {
    ["handheld_radio"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();