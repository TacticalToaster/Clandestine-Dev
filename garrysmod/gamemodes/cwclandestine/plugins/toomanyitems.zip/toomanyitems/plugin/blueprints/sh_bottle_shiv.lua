local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Weapon";
BLUEPRINT.description = "Smash the bottle to get a nice poky shiv.";
BLUEPRINT.model = "models/weapons/HL2meleepack/w_brokenbottle.mdl";
BLUEPRINT.name = "Bottle Shiv";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["weapon_hl2bottle"] = 1
};

BLUEPRINT.takeItems = {
	["weapon_hl2bottle"] = 1
};

BLUEPRINT.giveItems = {
    ["weapon_hl2brokenbottle"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();