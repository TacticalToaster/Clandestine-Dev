local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Breakdown";
BLUEPRINT.description = "Who needs a spare change of clothes?";
BLUEPRINT.model = "models/props_c17/SuitCase_Passenger_Physics.mdl";
BLUEPRINT.name = "Breakdown Suitcase";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["cw_suitcase"] = 1
};

BLUEPRINT.takeItems = {
    ["cw_suitcase"] = 1
};

BLUEPRINT.giveItems = {
    ["scrap_cloth"] = 8,
    ["scrap_nylon"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();