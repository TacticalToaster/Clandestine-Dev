local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Bundle";
BLUEPRINT.description = "Bundle up some gold to make more space.";
BLUEPRINT.model = "models/Items/AR2_Grenade.mdl";
BLUEPRINT.name = "Gold Bundle";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["scrap_gold"] = 5
};

BLUEPRINT.takeItems = {
    ["scrap_gold"] = 5
};

BLUEPRINT.giveItems = {
    ["bundle_gold"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();