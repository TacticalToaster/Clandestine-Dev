local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Bundle";
BLUEPRINT.description = "Bundle up some nylon to make more space.";
BLUEPRINT.model = "models/props_wasteland/prison_toiletchunk01i.mdl";
BLUEPRINT.name = "Nylon Bundle";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["scrap_nylon"] = 5
};

BLUEPRINT.takeItems = {
    ["scrap_nylon"] = 5
};

BLUEPRINT.giveItems = {
    ["bundle_nylon"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();