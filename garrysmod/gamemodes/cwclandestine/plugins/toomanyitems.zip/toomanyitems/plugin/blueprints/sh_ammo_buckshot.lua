local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Ammo";
BLUEPRINT.description = "Don't forget the wadding!";
BLUEPRINT.model = "models/Items/BoxBuckshot.mdl";
BLUEPRINT.name = ".12g Buckshot";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
	["gunpowder"] = 2,
	["scrap_plastic"] = 2,
	["scrap_iron"] = 2
};

BLUEPRINT.takeItems = {
    ["gunpowder"] = 2,
	["scrap_plastic"] = 2,
	["scrap_iron"] = 2
};

BLUEPRINT.giveItems = {
    ["ammo_buckshot"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();