local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Breakdown";
BLUEPRINT.description = "It wasn't made of much anyways.";
BLUEPRINT.model = "models/deadbodies/dead_male_civilian_radio.mdl";
BLUEPRINT.name = "Breakdown Remote Detonator";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["remote_detonator"] = 1
};

BLUEPRINT.takeItems = {
    ["remote_detonator"] = 1
};

BLUEPRINT.giveItems = {
    ["scrap_electronics"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();