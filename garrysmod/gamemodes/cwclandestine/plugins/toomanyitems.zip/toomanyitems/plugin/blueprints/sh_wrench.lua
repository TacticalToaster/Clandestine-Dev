local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Tools";
BLUEPRINT.description = "Craft a wrench from some crude materials.";
BLUEPRINT.model = "models/props_c17/tools_wrench01a.mdl";
BLUEPRINT.name = "Wrench";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["plate_iron"] = 3
};

BLUEPRINT.takeItems = {
    ["plate_iron"] = 3
};

BLUEPRINT.giveItems = {
    ["wrench"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();