local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Bundle";
BLUEPRINT.description = "Bundle up some copper to make more space.";
BLUEPRINT.model = "models/props_debris/rebar_smallnorm01c.mdl";
BLUEPRINT.name = "Copper Bundle";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["scrap_copper"] = 5
};

BLUEPRINT.takeItems = {
    ["scrap_copper"] = 5
};

BLUEPRINT.giveItems = {
    ["bundle_copper"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();