local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Ammo";
BLUEPRINT.description = "More bullets, more chances for 'accidents.'";
BLUEPRINT.model = "models/Items/BoxMRounds.mdl";
BLUEPRINT.name = "4.6x30mm Ammo";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
	["gunpowder"] = 3,
	["shell_casing"] = 3,
	["lead_bullet"] = 3
};

BLUEPRINT.takeItems = {
    ["gunpowder"] = 3,
	["shell_casing"] = 3,
	["lead_bullet"] = 3
};

BLUEPRINT.giveItems = {
    ["ammo_smg1"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();