local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Storage";
BLUEPRINT.description = "Use a bit of cloth to make a small bag.";
BLUEPRINT.model = "models/props_junk/garbage_bag001a.mdl";
BLUEPRINT.name = "Small Bag";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["scrap_cloth"] = 5
};

BLUEPRINT.takeItems = {
    ["scrap_cloth"] = 5
};

BLUEPRINT.giveItems = {
    ["small_bag"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();