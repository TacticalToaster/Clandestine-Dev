local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Unbundle";
BLUEPRINT.description = "Unbundle some kevlar to make more space.";
BLUEPRINT.model = "models/props_wasteland/prison_toiletchunk01i.mdl";
BLUEPRINT.name = "Unbundle Kevlar";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["bundle_kevlar"] = 1
};

BLUEPRINT.takeItems = {
    ["bundle_kevlar"] = 1
};

BLUEPRINT.giveItems = {
    ["scrap_kevlar"] = 5
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();