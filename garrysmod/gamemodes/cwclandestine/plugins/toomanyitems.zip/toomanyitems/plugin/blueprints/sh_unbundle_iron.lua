local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Unbundle";
BLUEPRINT.description = "Unbundle some iron to make more space.";
BLUEPRINT.model = "models/gibs/metal_gib2.mdl";
BLUEPRINT.name = "Unbundle Iron";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["bundle_iron"] = 1
};

BLUEPRINT.takeItems = {
    ["bundle_iron"] = 1
};

BLUEPRINT.giveItems = {
    ["scrap_iron"] = 5
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();