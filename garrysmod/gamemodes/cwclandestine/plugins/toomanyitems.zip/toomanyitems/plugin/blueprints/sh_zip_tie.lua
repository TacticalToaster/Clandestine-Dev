local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Misc.";
BLUEPRINT.description = "Binding someone isn't too hard if you have the know how to make some ties.";
BLUEPRINT.model = "models/Items/CrossbowRounds.mdl";
BLUEPRINT.name = "Zip Tie";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["scrap_plastic"] = 5,
    ["scrap_nylon"] = 2
};

BLUEPRINT.takeItems = {
    ["scrap_plastic"] = 5,
    ["scrap_nylon"] = 2
};

BLUEPRINT.giveItems = {
    ["zip_tie"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();