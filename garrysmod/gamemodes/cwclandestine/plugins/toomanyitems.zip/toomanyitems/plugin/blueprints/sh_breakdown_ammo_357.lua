local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Breakdown";
BLUEPRINT.description = "That's a big round.";
BLUEPRINT.model = "models/Items/357ammo.mdl";
BLUEPRINT.name = "Breakdown .357 Ammo";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
	["ammo_357"] = 1
};

BLUEPRINT.takeItems = {
    ["ammo_357"] = 1
};

BLUEPRINT.giveItems = {
    ["gunpowder"] = 3,
	["shell_casing"] = 2,
	["lead_bullet"] = 2
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();