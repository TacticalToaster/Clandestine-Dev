local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Refinement";
BLUEPRINT.description = "Use a hammer to make plates from copper.";
BLUEPRINT.model = "models/props_vents/vent_medium_grill002.mdl";
BLUEPRINT.name = "Plate Copper";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["scrap_copper"] = 2,
    ["hammer"] = 1
};

BLUEPRINT.takeItems = {
    ["scrap_copper"] = 2
};

BLUEPRINT.giveItems = {
    ["plate_copper"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();