local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Storage";
BLUEPRINT.description = "Use cloth and nylon to create a larger backpack.";
BLUEPRINT.model = "models/props_junk/garbage_bag001a.mdl";
BLUEPRINT.name = "Large Backpack";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["scrap_nylon"] = 2,
	["scrap_cloth"] = 2,
	["sewkit"] = 1
};

BLUEPRINT.takeItems = {
    ["scrap_nylon"] = 2,
	["scrap_cloth"] = 2
};

BLUEPRINT.giveItems = {
    ["large_backpack"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();