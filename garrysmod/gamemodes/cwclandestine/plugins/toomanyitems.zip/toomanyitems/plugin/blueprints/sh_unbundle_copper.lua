local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Unbundle";
BLUEPRINT.description = "Unbundle some copper to make more space.";
BLUEPRINT.model = "models/props_debris/rebar_smallnorm01c.mdl";
BLUEPRINT.name = "Unbundle Copper";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["bundle_copper"] = 1
};

BLUEPRINT.takeItems = {
    ["bundle_copper"] = 1
};

BLUEPRINT.giveItems = {
    ["scrap_copper"] = 5
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();