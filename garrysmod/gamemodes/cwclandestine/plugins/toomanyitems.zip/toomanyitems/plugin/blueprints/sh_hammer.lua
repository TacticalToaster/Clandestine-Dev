local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Tools";
BLUEPRINT.description = "Craft a hammer from some crude materials.";
BLUEPRINT.model = "models/props_c17/TrapPropeller_Lever.mdl";
BLUEPRINT.name = "Hammer";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["plate_iron"] = 1,
    ["wood_piece"] = 2,
    ["epoxy"] = 1
};

BLUEPRINT.takeItems = {
    ["plate_iron"] = 1,
    ["wood_piece"] = 2,
    ["epoxy"] = 1
};

BLUEPRINT.giveItems = {
    ["hammer"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();