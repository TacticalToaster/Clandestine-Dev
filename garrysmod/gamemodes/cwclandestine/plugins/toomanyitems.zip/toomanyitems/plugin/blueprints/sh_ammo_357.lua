local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Ammo";
BLUEPRINT.description = "Bigger bullet, bigger chance of blowing your arm off.";
BLUEPRINT.model = "models/Items/357ammo.mdl";
BLUEPRINT.name = ".357 Ammo";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
	["gunpowder"] = 3,
	["shell_casing"] = 2,
	["lead_bullet"] = 2
};

BLUEPRINT.takeItems = {
    ["gunpowder"] = 3,
	["shell_casing"] = 2,
	["lead_bullet"] = 2
};

BLUEPRINT.giveItems = {
    ["ammo_357"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();