local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Storage";
BLUEPRINT.description = "Use cloth to create a simple backpack.";
BLUEPRINT.model = "models/props_junk/garbage_bag001a.mdl";
BLUEPRINT.name = "Backpack";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["scrap_cloth"] = 10,
    ["sewkit"] = 1
};

BLUEPRINT.takeItems = {
    ["scrap_cloth"] = 10
};

BLUEPRINT.giveItems = {
    ["backpack"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();