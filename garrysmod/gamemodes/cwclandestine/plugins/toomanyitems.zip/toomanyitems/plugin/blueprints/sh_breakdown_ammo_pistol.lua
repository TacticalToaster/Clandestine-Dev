local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Breakdown";
BLUEPRINT.description = "There's a special powder in those bullets.";
BLUEPRINT.model = "models/Items/BoxSRounds.mdl";
BLUEPRINT.name = "Breakdown 9mm Ammo";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
	["ammo_pistol"] = 1
};

BLUEPRINT.takeItems = {
    ["ammo_pistol"] = 1
};

BLUEPRINT.giveItems = {
    ["gunpowder"] = 2,
	["shell_casing"] = 2,
	["lead_bullet"] = 2
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();