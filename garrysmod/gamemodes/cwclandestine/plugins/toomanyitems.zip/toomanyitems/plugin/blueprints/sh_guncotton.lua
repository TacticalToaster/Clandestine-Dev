local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Chemicals";
BLUEPRINT.description = "Mixing cloth, nitric acid, and sulfuric acid might give you something explosive.";
BLUEPRINT.model = "models/props_lab/jar01b.mdl";
BLUEPRINT.name = "Guncotton";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["scrap_cloth"] = 3,
    ["acid_nitric"] = 1,
    ["acid_sulfuric"] = 1
};

BLUEPRINT.takeItems = {
    ["scrap_cloth"] = 3,
    ["acid_nitric"] = 1,
    ["acid_sulfuric"] = 1
};

BLUEPRINT.giveItems = {
    ["guncotton"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();