local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Tools";
BLUEPRINT.description = "Craft a screwdriver from some crude materials.";
BLUEPRINT.model = "models/props_c17/TrapPropeller_Lever.mdl";
BLUEPRINT.name = "Screwdriver";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["plate_iron"] = 1,
    ["scrap_plastic"] = 2,
    ["epoxy"] = 1
};

BLUEPRINT.takeItems = {
    ["plate_iron"] = 1,
    ["scrap_plastic"] = 2,
    ["epoxy"] = 1
};

BLUEPRINT.giveItems = {
    ["screwdriver"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();