local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Unbundle";
BLUEPRINT.description = "Unbundle some steel to make more space.";
BLUEPRINT.model = "models/gibs/manhack_gib01.mdl";
BLUEPRINT.name = "Unbundle Steel";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["bundle_steel"] = 1
};

BLUEPRINT.takeItems = {
    ["bundle_steel"] = 1
};

BLUEPRINT.giveItems = {
    ["scrap_steel"] = 5
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();