local BLUEPRINT = Clockwork.crafting:New();

BLUEPRINT.category = "Bundle";
BLUEPRINT.description = "Bundle up some steel to make more space.";
BLUEPRINT.model = "models/gibs/manhack_gib01.mdl";
BLUEPRINT.name = "Steel Bundle";

BLUEPRINT.takeCash = 0;
BLUEPRINT.giveCash = 0;

BLUEPRINT.itemRequirements = {
    ["scrap_steel"] = 5
};

BLUEPRINT.takeItems = {
    ["scrap_steel"] = 5
};

BLUEPRINT.giveItems = {
    ["bundle_steel"] = 1
};

-- Called just before crafting.
function BLUEPRINT:OnCraft(player)
   
end;

-- Called just after crafting.
function BLUEPRINT:PostCraft(player)
   
end;

-- Called when crafting is unsuccessful.
function BLUEPRINT:FailedCraft(player)
   
end;

BLUEPRINT:Register();