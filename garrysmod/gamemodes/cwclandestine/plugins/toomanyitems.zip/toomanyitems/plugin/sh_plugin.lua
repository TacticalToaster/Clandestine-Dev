--[[
    This plugin was constructed using http://www.ClockworkConstructors.com, a free
    and easy to use web application to make your own Clockwork items, factions,
    plugins, and more! Brought to you by http://www.JonathanDroogh.com, aka RJ.
--]]

PLUGIN:SetGlobalAlias("TOOMANY")

Clockwork.kernel:IncludePrefixed("cl_hooks.lua");
Clockwork.kernel:IncludePrefixed("sv_hooks.lua");

Clockwork.flag:Add("E", "Explosives Expert", "Access to explosive related crafting blueprints.");
